﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetMover : MonoBehaviour
{

    public float speed = 2.0f;
    public float distance = 5.0f;

    public float radiusX = 15.0f;
    public float radiusY = 5.0f;
    public float radiusZ = 15.0f;

    private float time = 0;
    private float sineWaveTime = 0;
    Vector3 initialPosition;
    //  Vector3 v;

    private enum FlightPathType
    {
        Ellipse,
        SineWave,
        EllipseForwardBackwardFlip,
        EllipseSineWaveForwardSpeed
    };

    FlightPathType currentFlightPath = FlightPathType.Ellipse;

    public void Start()
    {
        initialPosition = GetComponent<Rigidbody>().transform.position;
        //v = speed * transform.right;
    }

    public void FixedUpdate()
    {
        MenuScript menuScript = GameObject.FindWithTag("Menu").GetComponent<MenuScript>();
        if (menuScript.paused) return;

        time += Time.deltaTime;

        if (currentFlightPath == FlightPathType.Ellipse)
        {
            radiusX = menuScript.radiusX;
            radiusY = menuScript.radiusY;
            radiusZ = menuScript.radiusZ;

            initialPosition.y = radiusY + 5;

            float factor = menuScript.velocity;

            if (time > factor)
            {
                time = 0;
            }

            float angle;
            if (factor > 0)
            {
                angle = (time * 360 / factor);
            }
            else
                angle = 0;

            float i = angle;

            //for (float i = 0; i < 360; i++) {
            float x = Mathf.Cos(i / 2 * Mathf.PI) * radiusX + initialPosition.x;
            float z = Mathf.Sin(i / 2 * Mathf.PI) * radiusZ + initialPosition.z;
            float y = Mathf.Sin(i / 2 * Mathf.PI) * radiusY + initialPosition.y;

            GetComponent<Rigidbody>().transform.position = new Vector3(x, y, z);
        }
        else
            if (currentFlightPath == FlightPathType.SineWave) {
                float x = time;


                radiusY = menuScript.radiusY;
                initialPosition.y = radiusY + 5;

                float factor = menuScript.velocity;

                if (time > factor)
                {
                    time = 0;
                }

                float angle;
                if (factor > 0)
                {
                    angle = (time * 360 / factor);
                }
                else
                    angle = 0;
                
                float y = Mathf.Sin(angle / 2 * Mathf.PI) * radiusY + initialPosition.y;
                float z = Mathf.Cos(angle / 2 * Mathf.PI) * radiusZ + initialPosition.z;

                if (time > menuScript.radiusX) {
                    time -= 2*menuScript.radiusX;
                }

                GetComponent<Rigidbody>().transform.position = new Vector3(x, y, z);

            }
        else
                if (currentFlightPath == FlightPathType.EllipseForwardBackwardFlip)
        {
                radiusX = menuScript.radiusX;
            radiusY = menuScript.radiusY;
            radiusZ = menuScript.radiusZ;

            initialPosition.y = radiusY + 5;

            float factor = menuScript.velocity;

            if (time > factor)
            {
                time = 0;
            }

            float angle;
            if (factor > 0)
            {
                // Map time on sine wave
                float timeAngle = time * 360 / factor;
                float substTime = Mathf.Sin(timeAngle)/2*Mathf.PI;
                sineWaveTime += Time.deltaTime * substTime;
                    angle = (sineWaveTime * 360 / factor);
            }
            else
                angle = 0;

            float i = angle;

            //for (float i = 0; i < 360; i++) {
            float x = Mathf.Cos(i / 2 * Mathf.PI) * radiusX + initialPosition.x;
            float z = Mathf.Sin(i / 2 * Mathf.PI) * radiusZ + initialPosition.z;
            float y = Mathf.Sin(i / 2 * Mathf.PI) * radiusY + initialPosition.y;


                GetComponent<Rigidbody>().transform.position = new Vector3(x, y, z);

            }
        if (currentFlightPath == FlightPathType.EllipseSineWaveForwardSpeed)
        {
            radiusX = menuScript.radiusX;
            radiusY = menuScript.radiusY;
            radiusZ = menuScript.radiusZ;

            initialPosition.y = radiusY + 5;

            float factor = menuScript.velocity;

            if (time > factor)
            {
                time = 0;
            }

            float angle;
            if (factor > 0)
            {
                // Map time on sine wave
                float timeAngle = time * 360 / factor;
                float substTime = Mathf.Sin(timeAngle*4) / 2 * Mathf.PI;
                sineWaveTime += Time.deltaTime * Mathf.Abs(substTime);
                angle = (sineWaveTime * 360 / factor);
            }
            else
                angle = 0;

            float i = angle;

            //for (float i = 0; i < 360; i++) {
            float x = Mathf.Cos(i / 2 * Mathf.PI) * radiusX + initialPosition.x;
            float z = Mathf.Sin(i / 2 * Mathf.PI) * radiusZ + initialPosition.z;
            float y = Mathf.Sin(i / 2 * Mathf.PI) * radiusY + initialPosition.y;


            GetComponent<Rigidbody>().transform.position = new Vector3(x, y, z);

        }

    }

    public void onFlightPathChanged(int pathTypeNr) {
        if (pathTypeNr == 0) {
            currentFlightPath = FlightPathType.Ellipse;
        }
        else
        if (pathTypeNr == 1)
        {
            currentFlightPath = FlightPathType.SineWave;
        }
        else
        if (pathTypeNr == 2)
        {
            currentFlightPath = FlightPathType.EllipseForwardBackwardFlip;
        }
        if (pathTypeNr == 3)
        {
            currentFlightPath = FlightPathType.EllipseSineWaveForwardSpeed;
        }

        
    }
}