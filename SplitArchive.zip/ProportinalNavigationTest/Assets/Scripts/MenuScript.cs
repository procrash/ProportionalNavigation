﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class MenuScript : MonoBehaviour {

    public int targetingBehaviourSelectedValue=2;

    public float radiusX = 5.0f;
    public float radiusY = 5.0f;
    public float radiusZ = 5.0f;

    public float velocity = 720.0f;

    public float maxTurnRate = 180.0f;  // turn rate in degrees per second
    public float maxThrust = 10.0f;     // maximum acceleration
    public float thrustRamp = 3.0f;     // how quickly full thrust becomes available
    public float turnRamp = 3.0f;       // how quickly full turning becomes available
    public float nc = 3.0f;             // gain, usually between 3 and 5
    public float ignitionDelay = 1.0f;  // delay between launch and activating thruster

    public bool paused = false;


    public void maxTurnRateChanged(string turnRate) {
        this.maxTurnRate = float.Parse(turnRate);
    }

    public void maxThrustChanged(string thrust)
    {
        this.maxThrust = float.Parse(thrust);
    }

    public void thrustRampChanged(string thrustRamp)
    {
        this.thrustRamp = float.Parse(thrustRamp);
    }

    public void turnRampChanged(string turnRamp)
    {
        this.turnRamp = float.Parse(turnRamp);
    }

    public void ncChanged(string nc)
    {
        this.nc = float.Parse(nc);
    }

    public void ignitionDelayChanged(string ignitionDelay)
    {
        this.ignitionDelay = float.Parse(ignitionDelay);
    }




    public void targetingBehaviourValueChanged(int value) {
        this.targetingBehaviourSelectedValue = value;
    }

    public void radiusXValueChanged(float value)
    {
        this.radiusX = value;
    }

    public void radiusYValueChanged(float value)
    {
        this.radiusY = value;
    }

    public void radiusZValueChanged(float value)
    {
        this.radiusZ = value;
    }

    public void velocityValueChanged(float value)
    {
        if (value == 0)
        {
            this.velocity = 0;
        }
        else
        {

            this.velocity = 2001 - value;
        }
    }


	// Use this for initialization
	void Start () {
        targetingBehaviourSelectedValue = 3;
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void onPauseClick() {

        /*
        if (!paused) {

            Time.timeScale = 0;

        } else {
            Time.timeScale = 1;
        }*/

        paused = !paused;


    }
    public void onExitClick() {
        Application.Quit();
    }
}
    
