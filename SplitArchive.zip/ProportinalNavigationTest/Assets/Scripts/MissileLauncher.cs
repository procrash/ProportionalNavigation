using UnityEngine;
using System.Collections;

public class MissileLauncher: MonoBehaviour {

	public Transform missilePrefab;	   // what to fire
	public Transform spawnPoint;       // where to fire it from
	public Vector3 launchVelocity;     // how fast, and in what direction, to eject the missile
	public Camera missileCam;          // optional missile cam, just for fun really
	public string fireButton = "Fire1";

	private Rigidbody body;

	public void Start() {
		body = transform.root.GetComponentInChildren<Rigidbody>();
	}

	public void Update() {
		// demo target selection: just find a game object tagged "Target"
		if (Input.GetButtonDown(fireButton)) {
			GameObject target = GameObject.FindWithTag("Target");
			if (target) {
				Fire(target.transform);
			} else {
				Debug.Log("No target found! Tag something as \"Target\" in your scene.");
			}
		}
	}

	public void Fire(Transform target) {
        Vector3 rot = transform.rotation.eulerAngles;
        rot.y = 0;

            
        Object obj = Instantiate(missilePrefab, spawnPoint.position, Quaternion.Euler(rot.x, rot.y, rot.z));

        if (obj!=null) {
            


        Transform missile = (Transform)obj;

 		missile.GetComponent<Rigidbody>().velocity = body.velocity + transform.rotation * launchVelocity;
		missile.GetComponent<GuidedMissile>().Fire(this, target.transform);
        }

	}
}